
const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3001;
const API_KEY = process.env.API_KEY; // Set this in Render env vars
const API_URL = 'https://api.runwayml.com/v1/generate'; // Replace with real API URL

app.post('/generate-video', async (req, res) => {
  const { prompt } = req.body;
  try {
    const response = await axios.post(API_URL, { prompt }, {
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Content-Type': 'application/json'
      }
    });
    res.json({ videoUrl: response.data.video_url });
  } catch (error) {
    res.status(500).json({ error: 'Video generation failed', details: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
