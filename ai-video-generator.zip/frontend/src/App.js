
import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [prompt, setPrompt] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const generateVideo = async () => {
    setLoading(true);
    try {
      const res = await axios.post('https://your-backend.onrender.com/generate-video', { prompt });
      setVideoUrl(res.data.videoUrl);
    } catch (err) {
      alert("Error generating video");
    }
    setLoading(false);
  };

  return (
    <div className="App">
      <h1>AI Video Generator</h1>
      <textarea
        placeholder="Enter your video prompt..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        rows="5"
        cols="50"
      />
      <br />
      <button onClick={generateVideo} disabled={loading}>
        {loading ? "Generating..." : "Generate Video"}
      </button>
      {videoUrl && (
        <video controls width="600" src={videoUrl} />
      )}
    </div>
  );
}

export default App;
